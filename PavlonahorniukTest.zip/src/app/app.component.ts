import {Component, OnInit} from '@angular/core';
import {UsersApiService} from "./services/users-api/users-api.service";
import {UsersStorageService} from "./services/users-storage/users-storage.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  usersList: any[] = [];

  constructor(
    private usersApiService: UsersApiService,
    private usersStorageService: UsersStorageService
  ) {
  }

  ngOnInit(): void {
    this.usersApiService.getUsers(25)
      .subscribe(res => {
        this.usersStorageService.setUsers(res.results);
      });

    this.usersStorageService.getUsers$()
      .subscribe(res => {
        this.usersList = res;
      })
  }

  openUser(id: number): void {
    if (id) {
      console.log('id: ', id);
    }
  }
}
