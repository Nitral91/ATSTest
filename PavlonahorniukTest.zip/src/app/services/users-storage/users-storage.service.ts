import {Injectable} from '@angular/core';
import {BehaviorSubject} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class UsersStorageService {

  usersList: BehaviorSubject<any[]> = new BehaviorSubject<any[]>([]);

  constructor() {
  }

  getUsers$(): BehaviorSubject<any[]> {
    return this.usersList;
  }

  setUsers(users: any[]): void {
    this.usersList.next(users);
  }

  getUserById(id: number): any {
    return this.getUsers$().value.find(user => {
      user.id.value === id;
    })
  }
}
