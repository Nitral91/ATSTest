import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root',
})
export class UsersApiService {
  constructor(
    private http: HttpClient
  ) {
  }

  getUsers(usersLimit?: number): Observable<any> {
    let params: {
      seed: string;
      results?: number
    } = {
      seed: 'interviewseed2023'
    }

    if (usersLimit) {
      params = {
        ...params,
        results: usersLimit
      }
    }

    return this.http.get('https://randomuser.me/api/', {
      params
    })
  }
}
